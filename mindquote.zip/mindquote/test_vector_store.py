# test_vector_store.py
from utils.quote_rag import create_vector_store
from langchain.docstore.document import Document

# Example: Add 5–10 quotes manually or from a file
quotes = [
    "The best way to predict the future is to invent it.",
    "Don't cry because it's over, smile because it happened.",
    "In the middle of every difficulty lies opportunity.",
    "Happiness is not something ready made. It comes from your own actions.",
    "Success is not final, failure is not fatal: It is the courage to continue that counts."
]

docs = [Document(page_content=quote) for quote in quotes]
create_vector_store(docs)
