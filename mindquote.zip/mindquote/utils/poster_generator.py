from PIL import Image, ImageDraw, ImageFont
import textwrap
import os

def generate_poster(quote, explanation, output_path="poster.png"):
    # Load background
    img = Image.new("RGB", (800, 1000), color=(245, 245, 245))

    draw = ImageDraw.Draw(img)
    font_path = "arial.ttf"  # You can replace with any .ttf file

    try:
        quote_font = ImageFont.truetype(font_path, 40)
        explain_font = ImageFont.truetype(font_path, 24)
    except:
        quote_font = ImageFont.load_default()
        explain_font = ImageFont.load_default()

    # Wrap text
    quote_text = textwrap.fill(f'"{quote}"', width=40)
    explanation_text = textwrap.fill(explanation, width=60)

    # Draw quote
    draw.text((50, 100), quote_text, font=quote_font, fill=(0, 0, 0))

    # Draw explanation
    draw.text((50, 400), explanation_text, font=explain_font, fill=(80, 80, 80))

    # Save poster
    img.save(output_path)
    print(f"✅ Poster saved to {output_path}")
