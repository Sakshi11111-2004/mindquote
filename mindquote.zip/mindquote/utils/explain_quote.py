from langchain_community.llms import HuggingFaceEndpoint

llm = HuggingFaceEndpoint(
    repo_id="HuggingFaceH4/zephyr-7b-beta",
    task="text-generation",
    huggingfacehub_api_token="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"  # 🔐 Put your working token directly here
)

def explain_quote(quote_text: str) -> str:
    prompt = f"Explain this quote in simple words:\n\n{quote_text}"
    return llm.invoke(prompt)
