from transformers import pipeline
import torch  # ✅ this ensures it uses PyTorch backend

# ✅ Hugging Face sentiment model
classifier = pipeline("text-classification", model="distilbert-base-uncased-finetuned-sst-2-english", framework="pt")

def classify_mood(user_input):
    result = classifier(user_input)[0]
    label = result['label'].lower()
    
    if "neg" in label:
        return "sad"
    elif "pos" in label:
        return "happy"
    else:
        return "neutral"
