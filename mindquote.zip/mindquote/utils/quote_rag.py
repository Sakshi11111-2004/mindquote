from langchain_community.vectorstores import Chroma
from langchain_community.embeddings import HuggingFaceEmbeddings
from langchain_community.llms import HuggingFaceEndpoint
from langchain.text_splitter import CharacterTextSplitter
from langchain.docstore.document import Document
from utils.explain_quote import explain_quote

# Step 1: Create vector store
def create_vector_store(docs):
    text_splitter = CharacterTextSplitter(chunk_size=500, chunk_overlap=50)
    texts = text_splitter.split_documents(docs)

    embeddings = HuggingFaceEmbeddings(model_name="all-MiniLM-L6-v2")
    vector_store = Chroma.from_documents(texts, embedding=embeddings, persist_directory="./quote_db")
    print("✅ Vector store created and persisted.")
    return vector_store

# Step 2: Load vector store
def load_vector_store():
    embeddings = HuggingFaceEmbeddings(model_name="all-MiniLM-L6-v2")
    vector_store = Chroma(persist_directory="./quote_db", embedding_function=embeddings)
    return vector_store

# ✅ Step 3: Retrieve and explain
def retrieve_and_explain_quote(query):
    db = load_vector_store()
    results = db.similarity_search(query, k=1)

    if not results:
        return "No quote found.", ""

    best_match = results[0].page_content
    print("🔍 Best Match:", best_match)

    explanation = explain_quote(best_match)

    return best_match, explanation
