from utils.mood_classifier import classify_mood
from utils.quote_rag import retrieve_and_explain_quote
from utils.poster_generator import generate_poster

query = input("Tell me how you feel or ask a question: ")
detected_mood = classify_mood(query)
print("🧠 Detected Mood:", detected_mood)

quote, explanation = retrieve_and_explain_quote(detected_mood)

print("\n💬 Quote:\n", quote)
print("\n🧠 Explanation:\n", explanation)

generate_poster(quote, explanation)

