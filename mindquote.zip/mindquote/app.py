import streamlit as st
from utils.mood_classifier import classify_mood
from utils.quote_rag import retrieve_and_explain_quote
from utils.poster_generator import generate_poster
from PIL import Image
import os

st.set_page_config(page_title="🧠 MindQuote - AI Quote Coach", layout="centered")

st.title("🧠 MindQuote")
st.subheader("Get a quote that matches your mood + explanation + poster!")

# User Input
user_input = st.text_input("💬 How are you feeling today? Or ask a question:")

if st.button("🔍 Get Quote"):
    if user_input.strip() == "":
        st.warning("Please enter how you're feeling or ask a question.")
    else:
        with st.spinner("Detecting mood..."):
            mood = classify_mood(user_input)
        st.success(f"🧠 Detected Mood: **{mood}**")

        with st.spinner("Finding the perfect quote..."):
            quote, explanation = retrieve_and_explain_quote(mood)
        
        st.markdown(f"### 💬 Quote:\n> *{quote}*")
        st.markdown(f"### 🧠 Explanation:\n{explanation}")

        with st.spinner("Generating poster..."):
            generate_poster(quote, explanation)

        if os.path.exists("poster.png"):
            st.image(Image.open("poster.png"), caption="🖼️ Your Quote Poster")
            with open("poster.png", "rb") as file:
                st.download_button("📥 Download Poster", file, file_name="mindquote_poster.png")

