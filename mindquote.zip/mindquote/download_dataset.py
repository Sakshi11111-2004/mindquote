from datasets import load_dataset
import pandas as pd
import os

# Load from HuggingFace
dataset = load_dataset("abirate/english_quotes", split="train")
df = pd.DataFrame(dataset)

# Keep only quote column
df = df[["quote"]]
os.makedirs("quote_data", exist_ok=True)
df.to_csv("quote_data/quotes.csv", index=False)

print("✅ Quotes saved to quote_data/quotes.csv")
